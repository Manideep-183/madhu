import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './redux/store';
import PostList from './components/PostList'; // Import the PostList component
import AddPost from './components/AddPost'; // Import the AddPost component
import './App.css';

const App = () => {
  return (
    <Provider store={store}>
      <Router>
        <Route path="/" exact component={PostList} /> {/* Route for Post List */}
        <Route path="/add-post" component={AddPost} /> {/* Route for Add Post */}
      </Router>
    </Provider>
  );
}

export default App;
