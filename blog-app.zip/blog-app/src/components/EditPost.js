import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { editPost } from '../redux/actions/postActions';

const EditPost = ({ post }) => {
  const [title, setTitle] = useState(post.title);
  const [content, setContent] = useState(post.content);

  const dispatch = useDispatch();

  const handleSave = () => {
    // Check if the title and content are not empty before dispatching
    if (title.trim() !== '' && content.trim() !== '') {
      dispatch(
        editPost({
          ...post,
          title,
          content,
        })
      );
    }
  };

  return (
    <div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter title"
      />

      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Enter content"
      />

      <button onClick={handleSave}>Save Post</button>
    </div>
  );
};

export default EditPost;
