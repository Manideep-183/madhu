import React from 'react';
import { useDispatch } from 'react-redux';
import { deletePost } from '../redux/actions/postActions';
import './styles/PostDetail.css'; // Import the PostDetail.css file from the styles folder

const PostDetail = ({ post }) => {
  const dispatch = useDispatch();

  const handleDelete = () => {
    const confirmDelete = window.confirm('Are you sure you want to delete this post?');
    if (confirmDelete) {
      dispatch(deletePost(post.id));
    }
  };

  return (
    <div className="post-detail">
      <div className="post-header">
        <h2>{post.title}</h2>
        <button onClick={handleDelete} className="delete-button">Delete Post</button>
      </div>
      <p className="post-content">{post.content}</p>
    </div>
  );
};

export default PostDetail;
