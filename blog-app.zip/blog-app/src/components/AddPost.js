import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addPost } from '../redux/actions/postActions';
import '../styles/AddPost.css'; // Import the AddPost.css file from the styles folder

const AddPost = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (title.trim() !== '' && content.trim() !== '') {
      dispatch(
        addPost({
          id: Date.now(),
          title,
          content,
        })
      );

      setTitle('');
      setContent('');
    }
  };

  return (
    <div className="add-post">
      <h2 className="add-post-title">Add New Post</h2>
      <form onSubmit={handleSubmit} className="add-post-form">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter title"
          className="add-post-input"
        />

        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Enter content"
          className="add-post-textarea"
        />

        <button type="submit" className="add-post-button">Add Post</button>
      </form>
    </div>
  );
};

export default AddPost;
