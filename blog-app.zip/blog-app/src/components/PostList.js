import React from 'react';
import { useSelector } from 'react-redux';  
import { Link } from 'react-router-dom';
import '../styles/PostList.css'; // Import the PostList.css file from the styles folder

const PostList = () => {
  console.log('PostList component rendered');

  const posts = useSelector(state => state.posts);

  return (
    <div className="post-content"> {/* Apply styles from PostList.css */}
      <h2>All Posts</h2>
      {posts.map(post => (
        <Link key={post.id} to={`/posts/${post.id}`} className="post-link">
          <h3>{post.title}</h3> 
          <p>{post.content}</p>
        </Link>
      ))}
    </div>
  );
}

export default PostList;
